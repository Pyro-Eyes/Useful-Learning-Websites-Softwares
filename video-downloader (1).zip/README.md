# 🎬 Video & Song Downloader

YouTube, Instagram aur TikTok ke videos aur Shorts/Reels ka link paste karo —
aur video **MP4** me ya song **MP3** me download karo.

**Ek hi code se 3 cheezein milti hain:**
1. 🌐 **Asli website ka URL** (internet par, phone + PC kahin se bhi) — free hosting se
2. 🖥️ **PC par** chala kar mobile se use karna (QR code se)
3. 📲 **Bina PC ke, seedha Android phone par** (Termux)

> **Sabse pehle ye samjho:** YouTube/Instagram se video nikaalne ke liye ek server chahiye hota hai —
> sirf ek HTML file (jo double-click se khule) ye kaam kar hi nahi sakti, browser ki security aur
> in platforms ki blocking ki wajah se. Isliye website ko ya to apne device par chalana padta hai,
> ya internet par kisi server par — dono ke steps neeche hain.

---

## 🌐 Option A: Asli website banao — free, ~5 minute, bina coding

**Hugging Face Spaces** par (drag & drop se ho jata hai):

1. [huggingface.co](https://huggingface.co) par **free account** banao (sign up → email confirm).
2. Upar right me **"New Space"** par click karo.
3. Naam do: `video-downloader` → **Space SDK: Docker** choose karo → **Blank** template → **Create Space**.
4. Ab **"Files"** tab me jao → **"Add file" → "Upload files"** → is zip ke ye 4 cheezein upload karo:
   - `app.py`
   - `Dockerfile`
   - `requirements.txt`
   - `templates` folder (`index.html` ke saath — Files me folder bana kar usme daalo)
5. **"Commit changes"** dabao. 3-5 minute me website ban jayegi.
6. Space ke upar jo link ho, wahi tumhari asli website hai — kuch aisa:
   `https://tumhara-naam-video-downloader.hf.space`
   **Phone, PC, kahin se bhi kholo aur use karo. Website link kisi ko bhi do!**

**Dhyan rakhne wali baatein:**
- Free Spaces thodi der tak use na ho to **so jati hain** — dobara kholne par 1-2 minute lagte hain, phir waise hi chalti hai.
- YouTube kabhi-kabhi cloud servers par **bot-check** laga deta hai ("Sign in to confirm" wala error).
  Aisa ho to thodi der baad try karo ya Option B/ C use karo (apne device par sabse bharosemand chalta hai).
- Aisi free websites ko hosting companies band bhi kar sakti hain — ye tumhari apni website hai, apni zimmedari par.

**Alternative hosts:** [render.com](https://render.com) ya [railway.app](https://railway.app) — wahan GitHub account se repo connect karke deploy karo (Procfile isi zip me diya hua hai). Steps same hain.

---

## 🖥️ Option B: PC par chalao, phone se bhi use karo (same WiFi)

1. [Python 3](https://www.python.org/downloads/) install karo (install karte waqt **"Add Python to PATH"** ✅ karna mat bhoolna).
2. Folder me `run.bat` double-click karo — browser me website khul jayegi: **http://localhost:5000**
3. Terminal me **QR code** dikhega — phone se scan karo, website phone me bhi khul jayegi.
   (Phone aur PC **ek hi WiFi** par hone chahiye.)

## 📲 Option C: Seedha Android phone par (Termux, PC ki zaroorat nahi)

1. [F-Droid](https://f-droid.org/packages/com.termux/) se **Termux** install karo (Play Store wala outdated hai).
2. Termux me:

```bash
pkg update -y && pkg install -y python ffmpeg
pip install -r requirements.txt     # files Termux me copy karke us folder me jao
python app.py
```

3. Phone ke browser me kholo: **http://localhost:5000**

---

## ✅ Kya-kya download ho sakta hai

| Platform | Video (MP4) | Song (MP3) |
|----------|:-----------:|:----------:|
| YouTube (video + Shorts) | ✅ | ✅ |
| Instagram (Reels + posts) | ✅ | ✅ |
| TikTok | ✅ | ✅ |

> Private videos ya login wali videos download nahi hongi.

## 📱 Istemaal kaise karein

1. Website par video ka **link paste** karo.
2. **Check** dabao — video ki photo, title, channel, length dikhegi.
3. **Download Video (MP4)** ya **Download Song (MP3)** dabao — file download ho jayegi.

## ❓ Common problems

- **"YouTube ne is network ko block kar diya hai"** — VPN band karke normal internet se try karo, ya `pip install -U yt-dlp` se update karo.
- **HF Space par bot-check error** — Space restart karo (Settings → Restart), thoda wait karke dobara try karo.
- **Phone se khulta hai par download nahi hota** — dono ek hi WiFi par hain? PC ka firewall "Allow" karo.
- **MP3 nahi ban raha** — `pip install imageio-ffmpeg` chala do (ya ffmpeg install karo).
- **Port busy** — `app.py` me port badal do (jaise 5001) aur wahi URL kholo.

## ⚖️ Zaroori baat

Ye tool sirf personal use ke liye hai. Sirf wahi videos download karo jinki permission tumhe hai
(apna content, Creative Commons, ya public domain). YouTube/Instagram/TikTok ke Terms of Service
unka content download karne se mana karte hain — apni zimmedari se istemaal karo.

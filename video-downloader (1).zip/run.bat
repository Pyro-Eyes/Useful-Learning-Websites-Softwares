@echo off
title Video ^& Song Downloader
cd /d "%~dp0"

echo ==========================================
echo   Video ^& Song Downloader start ho raha hai...
echo ==========================================
echo.

REM Pehli baar: requirements install karo
python -c "import flask, yt_dlp" 2>nul
if errorlevel 1 (
    echo Zaroori packages install ho rahe hain, ek baar wait karo...
    pip install -r requirements.txt
    echo.
)

start "" http://localhost:5000
python app.py

pause

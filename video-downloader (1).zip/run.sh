#!/bin/bash
# Video & Song Downloader - Mac/Linux start script
cd "$(dirname "$0")"

if ! python3 -c "import flask, yt_dlp" 2>/dev/null; then
    echo "Zaroori packages install ho rahe hain..."
    pip3 install -r requirements.txt
fi

echo
echo "Browser me kholo: http://localhost:5000"
echo "(Band karne ke liye Ctrl+C dabao)"
echo

( sleep 3; xdg-open http://localhost:5000 2>/dev/null || open http://localhost:5000 2>/dev/null ) &
python3 app.py

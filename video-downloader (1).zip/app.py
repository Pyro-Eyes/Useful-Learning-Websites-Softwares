"""
Video & Song Downloader Website
YouTube, Instagram, TikTok (aur 1000+ sites) se video (MP4) aur song (MP3) download karo.

Chalane ka tarika:
    pip install -r requirements.txt
    python app.py
Phir browser me kholo:  http://localhost:5000
"""

import os
import re
import glob
import shutil
import tempfile
import uuid

from flask import Flask, render_template, request, jsonify, send_file
import yt_dlp

# ---------------------------------------------------------------- ffmpeg ----
def find_ffmpeg():
    """Pehle system ka ffmpeg dhoondo, warna imageio-ffmpeg ka bundled binary."""
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


FFMPEG_PATH = find_ffmpeg()
ALLOWED_HOSTS = re.compile(
    r"(youtube\.com|youtu\.be|instagram\.com|instagr\.am|tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com)",
    re.IGNORECASE,
)

app = Flask(__name__)


# ------------------------------------------------------------- helpers ------
def base_ydl_opts():
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 30,
    }
    if FFMPEG_PATH:
        opts["ffmpeg_location"] = FFMPEG_PATH
    return opts


def clean_url(url):
    url = (url or "").strip()
    if not url:
        return None, "Link paste karo pehle."
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not ALLOWED_HOSTS.search(url):
        return None, "Ye link support nahi hota. Sirf YouTube, Instagram ya TikTok ka link daalo."
    return url, None


# ---------------------------------------------------------------- routes ----
@app.route("/")
def index():
    return render_template("index.html", ffmpeg_ok=bool(FFMPEG_PATH))


@app.route("/api/info", methods=["POST"])
def api_info():
    data = request.get_json(silent=True) or {}
    url, err = clean_url(data.get("url"))
    if err:
        return jsonify({"error": err}), 400

    opts = base_ydl_opts()
    opts["skip_download"] = True
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
        if not info:
            return jsonify({"error": "Video info nahi mil paayi. Link sahi hai kya?"}), 400

        # Playlist ho to pehla item le lo
        if "entries" in info:
            entries = [e for e in info["entries"] if e]
            if not entries:
                return jsonify({"error": "Is link me koi video nahi mila."}), 400
            info = entries[0]

        dur = info.get("duration") or 0
        return jsonify({
            "title": info.get("title") or "Unknown",
            "uploader": info.get("uploader") or info.get("channel") or "",
            "thumbnail": info.get("thumbnail") or "",
            "duration": int(dur),
            "webpage_url": info.get("webpage_url") or url,
        })
    except yt_dlp.utils.DownloadError as e:
        msg = str(e)
        if "Sign in to confirm" in msg or "not a bot" in msg:
            return jsonify({"error": "YouTube ne is network ko block kar diya hai. Apne normal internet/connection se try karo (VPN ya cloud server se nahi chalega)."}), 400
        if "Private" in msg or "login" in msg.lower() or "cookies" in msg.lower():
            return jsonify({"error": "Ye video private hai ya login maangti hai — download nahi ho sakti."}), 400
        if "Unsupported URL" in msg:
            return jsonify({"error": "Ye link support nahi hota."}), 400
        return jsonify({"error": "Video info nahi mili: " + msg[:200]}), 400
    except Exception as e:
        return jsonify({"error": "Kuch galat ho gaya: " + str(e)[:200]}), 500


@app.route("/api/download")
def api_download():
    url, err = clean_url(request.args.get("url"))
    if err:
        return err, 400

    fmt = request.args.get("fmt", "mp4")
    if fmt not in ("mp4", "mp3"):
        return "Galat format.", 400

    if fmt == "mp3" and not FFMPEG_PATH:
        return ("MP3 banane ke liye ffmpeg chahiye. 'ffmpeg' install karo ya "
                "'pip install imageio-ffmpeg' chala do."), 500

    tmpdir = tempfile.mkdtemp(prefix="dl_")
    outtmpl = os.path.join(tmpdir, "f.%(ext)s")

    opts = base_ydl_opts()
    opts["outtmpl"] = outtmpl
    opts["noplaylist"] = True

    if fmt == "mp3":
        opts["format"] = "ba/b"                      # best audio
        opts["postprocessors"] = [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }]
    else:
        opts["format"] = ("bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/"
                          "bv*+ba/b")                 # best mp4 jo mile

    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
        if "entries" in info:
            info = [e for e in info["entries"] if e][0]

        files = glob.glob(os.path.join(tmpdir, "*"))
        if not files:
            return "Download to hua par file nahi mili. Dobara try karo.", 500

        filepath = max(files, key=os.path.getsize)
        ext = os.path.splitext(filepath)[1].lstrip(".").lower() or "mp4"
        title = (info.get("title") or "video") if isinstance(info, dict) else "video"
        safe = re.sub(r"[^\w\s\-.()\[\]]", "", title, flags=re.UNICODE).strip()[:80] or "download"
        download_name = f"{safe}.{ext}"

        resp = send_file(filepath, as_attachment=True, download_name=download_name)

        @resp.call_on_close
        def _cleanup():
            shutil.rmtree(tmpdir, ignore_errors=True)

        return resp
    except yt_dlp.utils.DownloadError as e:
        shutil.rmtree(tmpdir, ignore_errors=True)
        msg = str(e)
        if "Sign in to confirm" in msg or "not a bot" in msg:
            return "YouTube ne is network ko block kiya hai. Apne normal internet se try karo.", 400
        if "Private" in msg or "login" in msg.lower():
            return "Ye video private hai ya login maangti hai.", 400
        return "Download fail hua: " + msg[:300], 400
    except Exception as e:
        shutil.rmtree(tmpdir, ignore_errors=True)
        return "Download fail hua: " + str(e)[:300], 500


if __name__ == "__main__":
    import socket

    port = int(os.environ.get("PORT", 5000))

    # LAN ka IP nikaalo taaki phone se bhi khul sake (same WiFi par)
    lan_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        lan_ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass

    print()
    print("=" * 56)
    print("  Video & Song Downloader chal raha hai:")
    print(f"  Is computer par :  http://localhost:{port}")
    if lan_ip != "127.0.0.1":
        print(f"  Mobile par (same WiFi):  http://{lan_ip}:{port}")
    print("=" * 56)
    if not FFMPEG_PATH:
        print("  [!] ffmpeg nahi mila — MP4 chalega, MP3 ke liye ffmpeg chahiye.")

    # Phone se asaani se kholne ke liye QR code
    if lan_ip != "127.0.0.1":
        try:
            import qrcode
            print()
            print("  Phone se ye QR scan karo (dono ek hi WiFi par hon):")
            qr = qrcode.QRCode(border=1)
            qr.add_data(f"http://{lan_ip}:{port}")
            qr.print_ascii(invert=True)
        except ImportError:
            print()
            print("  Tip: 'pip install qrcode' karne par phone ke liye QR code bhi dikhega.")
    print()
    app.run(host="0.0.0.0", port=port, debug=False)
